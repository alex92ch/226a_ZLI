package ch.zli.m226a.api28a;

import java.util.Random;

/**
 * A machine producing books and filling in Book Shelfs
 */
public class BookMachine {
	private static final int maxWidth = 6;
	private static final int maxHeight = 40;
	
	private static final Random rnd = new Random();

	int booksToHeight = 0, booksFilledIn = 0;
	
	public void fill(BookShelf bookShelf) {
		BookShelf.FillStatus status;
		do {
			status = bookShelf.addBook(createBook());
			if (status == BookShelf.FillStatus.ok) { ++booksFilledIn; }
			if (status == BookShelf.FillStatus.toHeiht) { ++booksToHeight; }
		} while (status != BookShelf.FillStatus.full);
	}

	private Book createBook() {
		return new Book(rnd.nextInt(maxWidth)+1, rnd.nextInt(maxHeight)+1);
	}

	@Override
	public String toString() {
		return "BookMachine [" + 
				"books to height: " + booksToHeight + ", " + 
				"stored books: " + booksFilledIn + "]";
	}
	
	
}

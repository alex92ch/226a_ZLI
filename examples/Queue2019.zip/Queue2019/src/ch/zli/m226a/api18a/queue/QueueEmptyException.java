package ch.zli.m226a.api18a.queue;

@SuppressWarnings("serial")
public class QueueEmptyException extends RuntimeException {
	
	public QueueEmptyException() { super(); }
	
	public QueueEmptyException(String message) {
		super(message);
	}
}

package ch.zli.m226a.api18a.queue;

@SuppressWarnings("serial")
public class QueueFullException extends RuntimeException {
	public QueueFullException() { super(); }
	
	public QueueFullException(String message) {
		super(message);
	}
}

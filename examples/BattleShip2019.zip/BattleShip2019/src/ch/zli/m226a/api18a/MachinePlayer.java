package ch.zli.m226a.api18a;

import java.util.Random;

public class MachinePlayer implements Player {
	private static final Random rnd = new Random();
	
	private String name;
	private int score;
	
	public MachinePlayer(String name) {
		this.name = name;
		score = 0;
	}

	@Override public String getName() { return name; }
	@Override public int getScore() { return score; }
	@Override public void incrementScore() { score++; }

	@Override
	public Coord getTargetPosition() {
		int x, y;
		x = rnd.nextInt(Bord.maxX);
		y = rnd.nextInt(Bord.maxY);
		return new Coord(x, y);
	}
}

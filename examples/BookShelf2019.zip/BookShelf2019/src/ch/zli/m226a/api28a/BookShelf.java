package ch.zli.m226a.api28a;

import java.util.ArrayList;
import java.util.List;

/**
 * Bookshelf can store Books
 */
public class BookShelf {

	/**
	 * Result enumeration for storing a book
	 */
	public enum FillStatus {ok, toHeiht, full}
	
	private int height;
	private List<Shelf> shelfs;

	/**
	 * Constructor
	 * @param height the book shelfs height
	 * @param width the book shelfs 
	 * @param nbrOfShelfs the number of needed shelfs
	 */
	public BookShelf(int height, int width, int nbrOfShelfs) {
		this.height = height;
		shelfs = new ArrayList<Shelf>();
		for (int i = 0; i < nbrOfShelfs; ++i) {
			shelfs.add(new Shelf(width));
		}
	}
	
	/**
	 * Add a book to the book shelf
	 * @param book the book to be added
	 * @return 
	 * 	ok if the book is added, 
	 * 	toHeight if the book is to height, 
	 * 	full if there is no more room to store teh book
	 */
	public FillStatus addBook(Book book) {
		if (book.getHeight() > height/shelfs.size()) {
			return FillStatus.toHeiht;
		}
		for (Shelf shelf : shelfs) {
			if (shelf.addBook(book)) {
				return FillStatus.ok;
			}
		}
		return FillStatus.full;
	}
}

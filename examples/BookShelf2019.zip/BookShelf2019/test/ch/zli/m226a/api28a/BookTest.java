package ch.zli.m226a.api28a;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class BookTest {

	@Test
	void testGetter() {
		Book book = new Book(5, 20);
		assertEquals(5, book.getWidth());
		assertEquals(20, book.getHeight());
	}
}

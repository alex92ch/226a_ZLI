package ch.zli.m226a.api18a;

import java.util.List;

public class Ship {
	private List<Coord> parts;

	public Ship(List<Coord> parts) {
		this.parts = parts;
	}
	
	public boolean isHit(Coord pos) {
		if (parts.contains(pos)) {
			parts.remove(pos);
			return true;
		}
		return false;
	}
	
	public boolean isSunken() {
		return parts.isEmpty();
	}
	
	@Override
	public String toString() {
		return "Ship: " + parts.toString();
	}
}

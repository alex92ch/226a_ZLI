package ch.zli.m226a.api18a.queue.implementation;

import java.util.ArrayList;
import java.util.List;

import ch.zli.m226a.api18a.queue.Queue;

public class QueueList<T> implements Queue<T> {
	private List<T> elements; // Variable declaration
	
	public QueueList() {
		elements = new ArrayList<>(); // Object instantiation
	}
	
	public void add(T element) {
		elements.add(element); // end of list
	}
	
	public T remove() {
		// todo
		return elements.remove(0); // begin of list
	}
	
	public boolean isEmpty() { return elements.isEmpty(); }
	
	public boolean isFull() { return false; }
	
	public int size() { return elements.size(); }
}

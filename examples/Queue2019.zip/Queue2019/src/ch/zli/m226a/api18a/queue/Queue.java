package ch.zli.m226a.api18a.queue;

/**
 * Implements a FIFO
 * @param <T> type of the elements in the Queue
 */
public interface Queue<T> {
	/**
	 * Adds an element to the queue
	 * @param element the element to be added
	 * @throws QueueFullException if {@link #isFull()} is true
	 */
	public void add(T element);
	
	/**
	 * Removes an element from the queue
	 * @return the removed element
	 * @throws QueueEmptyException if {@link #isEmpty()} is true
	 */
	public T remove();
	
	/**
	 * @return true if queue is empty, false otherwise
	 */
	public boolean isEmpty();
	
	/**
	 * @return true if queue is full, false otherwise
	 */
	public boolean isFull();
	
	/**
	 * @return the number of elements in the queue
	 */
	public int size();
}

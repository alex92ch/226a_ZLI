package ch.zli.m226a.api18a;

import java.util.ArrayList;
import java.util.List;

public class Game {
	private List<Ship> ships;
	private List<Player> players;
	
	private Game() {
		ships = new ArrayList<Ship>();
		players = new ArrayList<Player>();
		System.out.println(
				"Board dimension max: " + new Coord(Bord.maxX-1, Bord.maxY-1));
	}
	
	public Game(int nbrOfShips, int nbrOfMachinePlayers,int nbrOfHumanPlayers) {
		this();
		createShips(nbrOfShips);
		createHumanPlayer(nbrOfHumanPlayers);
		createMachinePlayer(nbrOfMachinePlayers);
	}
	
	public Game(int nbrOfShips, int nbrOfPlayers) {
		this();
		createShips(nbrOfShips);
		createMachinePlayer(nbrOfPlayers);
	}
	
	public void playGame() {
		while(!endOfGame()) {
			for(Player player : players) {
				Coord pos = player.getTargetPosition();
				for(Ship ship : ships) {
					if (ship.isHit(pos)) {
						player.incrementScore();
						printHitStatus(player, ship, pos);
					}
				}
			}
		}
		printStatistics();
	}
	
	private boolean endOfGame() {
		for(Ship ship : ships) {
			if (!ship.isSunken()) { return false; }
		}
		return true;
	}
	
	private void printHitStatus(Player player, Ship ship, Coord pos) {
		System.out.print(player.getName() + " has hit at " + pos);
		if(ship.isSunken()) {
			System.out.println(" and the ship is sunken");
		} else {
			System.out.println();
		}
	}
	
	private void printStatistics() {		
		System.out.println("Game finished, Scores:");
		for(Player player : players) {
			System.out.println(
					"\t" + player.getName() + 
					"\t" + player.getScore());
		}
	}
	
	private void createShips(int nbrOfShips) {
		ships = new ArrayList<>();
		for(int i = 0; i < nbrOfShips; ++i) {
			ships.add(Bord.getNewShip());
		}
		System.out.println(ships);
	}

	private void createHumanPlayer(int nbrOfPlayers) {
		for (int i = 0; i < nbrOfPlayers; ++i) {
			players.add(new HumanPlayer());
		}
	}
	
	private void createMachinePlayer(int nbrOfPlayers) {
		for (int i = 0; i < nbrOfPlayers; ++i) {
			players.add(new HumanPlayer());
		}
	}

}

package ch.zli.m226a.api18a;

public enum CatState {
	sleepy, hungry, needsAttention;
}

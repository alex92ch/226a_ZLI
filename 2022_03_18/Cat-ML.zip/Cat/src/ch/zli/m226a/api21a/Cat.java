package ch.zli.m226a.api21a;

// Line comment
/* Block comment */
/** JavaDoc comment */

/**
 * A Cat class for learning about objects
 */
public class Cat {
	protected enum CatState {hungry, playful, sleepy}
	
	private String color;
	private String name;
	private CatState state;
	
	/**
	 * Constructor
	 * @param color the cats fur color
	 */
	public Cat(String color) {
		this(color, "");
	}
	
	/**
	 * Constructor
	 * @param color the cats fur color
	 * @param name the cats name
	 */
	public Cat(String color, String name) {
		this.color = color;
		this.name = name;
		state = CatState.hungry;
	}

	/** the cats fur color */
	public String getColor()  { return color; }
	
	/** the cats name */
	public String getName()   { return name;  }
	
	/** the cats mood */
	public CatState getMood() { return state; }

	/**
	 * Baptize the cat
	 * @param name its new name
	 */
	public void baptize(String name) {
		this.name = name;
	}
	
	/**
	 * Let the cat sleep to make her playful
	 */
	public void sleep() {
		if (state == CatState.sleepy) { state = CatState.playful; }
	}
	
	/**
	 * Play with the cat to make her hungry
	 */
	void play() {
		if (state == CatState.playful) { state = CatState.hungry; }
	}
	
	/**
	 * Let the cat eat to make her sleepy
	 */
	public void eat() {
		if (state == CatState.hungry) { state = CatState.sleepy; }
	}

	@Override
	public String toString() {
		return "Cat [color=" + color + ", name=" + name + ", state=" + state + "]";
	}
	}

package ch.zli.m226a.api18a;

import java.util.Scanner;

public class HumanPlayer implements Player {

	private String name;
	private int score;
	
	public HumanPlayer() {
		// read name from console
		name = readName();
		score = 0;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public int getScore() {
		return score;
	}

	@Override
	public void incrementScore() {
		++score;
	}

	@Override
	public Coord getTargetPosition() {
		// read target position from the console
		System.out.print(name + " enter target position: "); // Output range ??!
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		return new Coord(input);
	}

	private String readName() {
		String res;
		do {
			System.out.print("Enter your name:");
			@SuppressWarnings("resource") // in is not our property
			Scanner scanner = new Scanner(System.in);
			res = scanner.nextLine();
		} while(res.trim().isEmpty());
		return res;
	}
}

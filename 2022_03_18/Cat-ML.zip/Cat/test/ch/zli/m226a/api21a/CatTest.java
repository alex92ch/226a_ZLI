package ch.zli.m226a.api21a;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CatTest {
	
	/*
	 * Given
	 * when
	 * then
	 */

	@Test
	void a_new_cat_ctor_with_color_only_argument() {
		Cat cat = new Cat("black");
		assertEquals("black", cat.getColor());
		assertEquals("", cat.getName());
		assertEquals(Cat.CatState.hungry, cat.getMood());
	}
	
	@Test
	void a_new_cat_ctor_with_color_and_name_arguments() {
		Cat cat = new Cat("black", "Ronny");
		assertEquals("black", cat.getColor());
		assertEquals("Ronny", cat.getName());
		assertEquals(Cat.CatState.hungry, cat.getMood());
	}
	
	@Test
	void a_cat_baptized_by_name() {
		Cat cat =new Cat("color");
		cat.baptize("Suseli");
		assertEquals("Suseli", cat.getName());
	}
	
	@Test
	void a_sleepy_cat_after_sleeping_is_playful() {
		Cat cat = new Cat("black");
		cat.eat();   // is sleepy now
		cat.sleep();
		assertEquals(Cat.CatState.playful, cat.getMood());
	}
	
	@Test
	void a_playful_cat_after_playing_is_hungry() {
		Cat cat = new Cat("black");
		cat.eat();   // is sleepy now
		cat.sleep(); // is playful now
		cat.play();
		assertEquals(Cat.CatState.hungry, cat.getMood());
	}
	
	@Test
	void a_hungry_cat_after_eating_is_sleepy() {
		Cat cat = new Cat("black");
		cat.eat();
		assertEquals(Cat.CatState.sleepy, cat.getMood());
	}
	
	@Test
	void a_new_black_cat_named_ronny_as_string() {
		Cat cat = new Cat("black", "Ronny");
		assertEquals(
				"Cat [color=" + "black" + ", name=" + "Ronny" + ", state=" + "hungry" + "]",
				cat.toString()
		);
	}
}

package ch.zli.m226a.api28a;

public class Shelf {

	private int freeSpace;
	
	/**
	 * Constructor
	 * @param width the width of the shelf
	 */
	public Shelf(int width) {
		freeSpace = width;
	}

	/**
	 * Try to add a book to us
	 * @param book the book to be added
	 * @return true on success, false if there is not enough free space left
	 */
	public boolean addBook(Book book) {
		if (freeSpace >= book.getWidth()) {
			freeSpace -= book.getWidth();
			return true;
		}
		return false;
	}
}

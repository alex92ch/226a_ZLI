package ch.zli.m226a.api18a.queue.implementation;

import static org.junit.Assert.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ch.zli.m226a.api18a.queue.Queue;
import ch.zli.m226a.api18a.queue.QueueEmptyException;
import ch.zli.m226a.api18a.queue.QueueFullException;

public class QueueArrayExceptionTest {

private Queue<String> queue;
	
	@BeforeEach
	void init() {
		queue = new QueueArray<>();
	}
	
	@Test
	public void emptyExceptionTest() {
		try {
			queue.remove();
			fail("Need a QueueEmptyException");
		} catch(QueueEmptyException exeption) {
			// test ok
		}
	}
	
	@Test
	public void fullExceptionTest() {
		while (!queue.isFull()) {
			queue.add("42"); // loops for ever on failure
		}
		try {
			queue.add("Boom");
			fail("Need a QueueFullException");
		} catch (QueueFullException exeption) {
			// Test OK
		}

	}
}

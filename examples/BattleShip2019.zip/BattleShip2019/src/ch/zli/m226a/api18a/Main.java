package ch.zli.m226a.api18a;

public class Main {

	public static void main(String[] args) {
		//new Game(5, 2).playGame();
		new Game(5, 1, 1).playGame();
	}
}

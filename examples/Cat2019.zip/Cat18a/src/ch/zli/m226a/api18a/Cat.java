package ch.zli.m226a.api18a;

public class Cat {
	private String color;
	private String name;
	private CatState state;
	
	public Cat(String color) {
		this.color = color;
		name = "";
		state = CatState.hungry;
	}
	
	String getColor() { return color; }
	
	public String getNamme() { return name; }
	public void setName(String name) {this.name = name; }
	
	public CatState getState() { return state; }
	
	public void eat() {
		switch (state) {
		case sleepy:
		case hungry:
		case needsAttention:
			state = CatState.sleepy;
			break;
		}
	}
	
	public void play() {
		switch (state) {
		case sleepy:
		case hungry:
		case needsAttention:
			state = CatState.hungry;
			break;
		}
	}
	public void receiveLove() {
		switch (state) {
		case sleepy:
			state = CatState.needsAttention;
			break;
		case hungry:
			state = CatState.hungry;
			break;
		case needsAttention:
			state = CatState.needsAttention;
			break;
		}
	}
}

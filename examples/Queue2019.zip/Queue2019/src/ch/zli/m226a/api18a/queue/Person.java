package ch.zli.m226a.api18a.queue;

public class Person {

	private String name;
	
	public Person(String name) {
		this.name = name;
	}
	
	public String getName() { return name; }
}

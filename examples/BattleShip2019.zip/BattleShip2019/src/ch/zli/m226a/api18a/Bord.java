package ch.zli.m226a.api18a;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Bord {
	private static final Random rnd = new Random();
	
	public final static int maxX = 10;
	public final static int maxY = 10;
	private static List<Coord> alreadyUsedPositions = new ArrayList<Coord>();

	public static Ship getNewShip() {
		int shipLength;
		boolean isHorizontal;
		List<Coord> shipPosition = new ArrayList<>();
		
		int maxLoop = 10;
		do {
			shipPosition.clear();
			if (maxLoop-- == 0) { break; }
			
			isHorizontal = rnd.nextBoolean();
			shipLength = 2 + rnd.nextInt(3); // [2..4]
			int maxStartX, maxStartY;
			// Calculate random max values
			if (isHorizontal) {
				maxStartX = maxX-shipLength+1;
				maxStartY = maxY;
			} else {
				maxStartX = maxX;
				maxStartY = maxY-shipLength+1;
			}
			int x = rnd.nextInt(maxStartX);
			int y = rnd.nextInt(maxStartY);
			shipPosition.add(new Coord(x, y));
			for (int i = 0; i < shipLength-1; ++i) {
				if (isHorizontal) { ++x; } else { ++y; }
				shipPosition.add(new Coord(x, y));
			}
		} while (!isFree(shipPosition));
		reservePositions(shipPosition);
		
		return new Ship(shipPosition);
	}
	
	private static void reservePositions(List<Coord> toBeReserved) {
		for (Coord coord : toBeReserved) {
			alreadyUsedPositions.add(coord);
		}
	}
	
	private static boolean isFree(List<Coord> positions) {
		for (Coord coord : positions) {
			if (alreadyUsedPositions.contains(coord)) { return false; }
		}
		return true;
	}
}

package ch.zli.m226a.api21a;

public class Main {

	public static void main(String[] args) {
		Cat ronny;
		ronny = new Cat("black", "Ronny");
		System.out.println(ronny);
//		ronny.state = Cat.CatState.playful; // Bad habit
		
		ronny.eat();
		ronny.sleep();
		
		System.out.println(ronny);
		Cat sheewa = ronny;
		System.out.println(sheewa);
		Cat heewa = new Cat("red");
		System.out.println(heewa);
		System.out.println(ronny.getMood());
		// Cat.CatSate state; not possible
	}

}

package ch.zli.m226a.api28a;

public class Main {

	public static void main(String[] args) {
		BookMachine bookMachine = new BookMachine();
		BookShelf bookShelf = new BookShelf(200, 80, 6);
		System.out.println("Start filling:");
		bookMachine.fill(bookShelf);
		System.out.println(bookMachine);
	}

}

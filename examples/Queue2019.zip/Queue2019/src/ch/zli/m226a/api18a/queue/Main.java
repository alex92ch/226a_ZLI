package ch.zli.m226a.api18a.queue;

import ch.zli.m226a.api18a.queue.implementation.QueueArray;
import ch.zli.m226a.api18a.queue.implementation.QueueList;

public class Main {
	public static void main(String[] args) {		
		test(new QueueList<>());
		test(new QueueArray<>());
	}
	
	public static void test(Queue<Person> queue) {
		System.out.println("Ist leer: " + queue.isEmpty());
		
		queue.add(new Person("Max"));
		queue.add(new Person("Trax"));
		queue.add(new Person("Susi"));
		
		System.out.println("Size soll 3, ist : " + queue.size());
		
		System.out.println("Name soll Max, ist: " + queue.remove().getName());
		System.out.println("Name soll Trax, ist: " + queue.remove().getName());
		System.out.println("Name soll Susi, ist: " + queue.remove().getName());
		
		System.out.println("Size soll 0, ist : " + queue.size());
		
		System.out.println("Ist leer: " + queue.isEmpty());
	}
}

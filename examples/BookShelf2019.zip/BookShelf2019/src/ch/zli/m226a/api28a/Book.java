package ch.zli.m226a.api28a;

/**
 * Books carry only their dimension 
 */
public class Book {

	private int width;
	private int height;

	/**
	 * Constructor
	 * @param width the books width
	 * @param height the books height
	 */
	public Book(int width, int height) {
		this.width = width;
		this.height = height;
	}
	public int getHeight() { return height; }
	public int getWidth() { return width; }
}

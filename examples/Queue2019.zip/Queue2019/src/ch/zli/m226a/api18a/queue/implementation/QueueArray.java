package ch.zli.m226a.api18a.queue.implementation;

import ch.zli.m226a.api18a.queue.Queue;
import ch.zli.m226a.api18a.queue.QueueEmptyException;
import ch.zli.m226a.api18a.queue.QueueFullException;

/**
 * Implements {@link ch.zli.m226a.api18a.queue.Queue Queue}
 * with a limited sized array.</br>
 * Fast butt size limited.
 */
public class QueueArray<T> implements Queue<T> {
	private static final int defaultSize = 10;
	
	private T elements[];
	private int nextInsertPos;
	private int elementCount;
	
	/** Constructor */
	public QueueArray() {
		this(defaultSize);
	}
	
	/** @param maxSize capacity of the queue */
	@SuppressWarnings("unchecked")
	public QueueArray(int maxSize) {
		elements = (T[])new Object[maxSize];
		nextInsertPos = 0;
		elementCount = 0;
	}
	
	@Override
	public void add(T element) {
		if (isFull()) { throw new QueueFullException("Queue already full"); } // error
		
		elements[nextInsertPos] = element;
		nextInsertPos = (nextInsertPos + 1) % elements.length;
		elementCount++;
	}
	
	@Override
	public T remove() {
		if (isEmpty()) { throw new QueueEmptyException("Queue already empty"); }
		int removeIdx = 
			(nextInsertPos - elementCount + elements.length) % elements.length;
		elementCount--;
		return elements[removeIdx];
	}
	
	@Override public boolean isEmpty() { return elementCount == 0; }
	@Override public boolean isFull() { return elementCount == elements.length; }
	@Override public int size() { return elementCount; }
}

package ch.zli.m226a.api28a;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class BookShelfTest {
	
	@Test
	void addBookTest() {
		BookShelf bookShelf = new BookShelf(200, 80, 6);
		Book book = new Book(1, 25);
		assertEquals(BookShelf.FillStatus.ok, bookShelf.addBook(book));
		book = new Book(1, 40);
		assertEquals(BookShelf.FillStatus.toHeiht, bookShelf.addBook(book));
		book = new Book(81, 30);
		assertEquals(BookShelf.FillStatus.full, bookShelf.addBook(book));
	}
}

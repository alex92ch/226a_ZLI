package ch.zli.m226a.api18a;

public class Main {
	public static void main(String[] args) {
		Cat ronny = new Cat("black");
		ronny.setName("Ronny");
		ronny.eat();
		ronny.play();
		ronny.receiveLove();
		
		System.out.println(ronny.getColor());
		System.out.println(ronny.getNamme());
		System.out.println(ronny.getState());
		ronny.receiveLove();
		System.out.println(ronny.getState());
		ronny.eat();
		System.out.println(ronny.getState());
		
		
		/*
		Cat susi = new Cat("red");
		System.out.println(susi.getColor());
		
		System.out.println(susi.getClass().getName());
		System.out.println(ronny.getClass().getSimpleName());
		*/
	}
}

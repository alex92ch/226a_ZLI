package ch.zli.m226a.api18a;

public interface Player {
	String getName();
	int getScore();
	void incrementScore();
	Coord getTargetPosition();
}

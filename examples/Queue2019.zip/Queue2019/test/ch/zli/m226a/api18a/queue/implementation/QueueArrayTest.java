package ch.zli.m226a.api18a.queue.implementation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ch.zli.m226a.api18a.queue.Queue;

class QueueArrayTest {

	private Queue<String> queue;
	
	@BeforeEach
	void init() {
		queue = new QueueArray<>();
	}
	
	@Test void isEmptyTest() {
		assertTrue(queue.isEmpty(), "Should be empty afte new");
	}

	@Test void sizeTest() {
		assertEquals(0, queue.size());
		
		queue.add("Max");
		queue.add("Trax");
		
		assertEquals(2, queue.size());
	}
	
	@Test void fifoTest() {
		String data[] = {"Max", "Trax", "Susi", "Helen"};
		
		for (int i = 0; i < data.length; ++i) {
			queue.add(data[i]);
		}
		for (int i = 0; i < data.length; ++i) {
			assertEquals(data[i], queue.remove());
		}
	}
	
	@Test void ringBufferTest() {
		String data[] = {"Max", "Trax", "Susi", "Helen"};
		
		// add and remove at least 6 for ring buffer overflow
		for (int i = 0; i < data.length; ++i) {
			queue.add(data[i]);
			queue.remove();
			queue.add(data[i]);
			queue.remove();
		}
		// Now we have a ring buffer overflow
		for (int i = 0; i < data.length; ++i) {
			queue.add(data[i]);
		}
		for (int i = 0; i < data.length; ++i) {
			assertEquals(data[i], queue.remove());
		}
	}
	
	@Test void isFullTest() {
		assertFalse(queue.isFull());
		
		// whacky
		while (!queue.isFull()) {
			queue.add("42"); // loops for ever on failure
		}
	}
}

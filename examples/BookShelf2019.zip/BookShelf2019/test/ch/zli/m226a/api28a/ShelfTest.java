package ch.zli.m226a.api28a;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

public class ShelfTest {

	@Test
	void addBookTest() {
		Shelf shelf = new Shelf(80);
		Book book;
		for (int i = 0; i < 8; ++i) {
			book = new Book(10, 25);
			assertTrue(shelf.addBook(book));
		}
		book = new Book(10, 25);
		assertFalse(shelf.addBook(book));
	}
}
